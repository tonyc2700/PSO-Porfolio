#ifndef __GHCCONFIG_H__
#define __GHCCONFIG_H__

#include "ghcautoconf.h"
#include "ghcplatform.h"

#endif
