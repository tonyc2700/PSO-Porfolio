
char *getExecutable(void);
char *getExecutablePath(void);

