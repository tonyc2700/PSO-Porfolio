#if defined(HAS_VISIBILITY_HIDDEN) && !defined(freebsd_HOST_OS)
#pragma GCC visibility pop
#endif
