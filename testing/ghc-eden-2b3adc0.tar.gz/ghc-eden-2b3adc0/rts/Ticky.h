/* -----------------------------------------------------------------------------
 *
 * (c) The GHC Team 1999
 *
 * Header for Ticky.c
 *
 * ---------------------------------------------------------------------------*/

#ifndef TICKY_H
#define TICKY_H

RTS_PRIVATE void PrintTickyInfo(void);

#endif /* TICKY_H */
