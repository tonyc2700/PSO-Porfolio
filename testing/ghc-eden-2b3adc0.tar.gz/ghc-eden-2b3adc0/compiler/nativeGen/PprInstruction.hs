
        pprInstruction :: Platform -> instr -> SDoc
